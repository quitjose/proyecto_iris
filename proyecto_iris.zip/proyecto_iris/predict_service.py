def predict_single(customer, model):
    print(type(model))
    PetalLength, PetalWidth = list(customer.values())
    print(model.predict_proba([[PetalLength, PetalWidth]]))
    return model.predict([[PetalLength, PetalWidth]])[0], model.predict([[PetalLength, PetalWidth]])

