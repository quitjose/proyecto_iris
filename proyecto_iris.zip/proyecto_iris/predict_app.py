import pickle
from flask import Flask, jsonify, request
from predict_service import predict_single

app = Flask('iris-predict')

with open('models/iris-regresion_model.pck', 'rb') as f:
    model = pickle.load(f)

print(type(model))

@app.route('/predict', methods=["POST"])
def predict():
    customer = request.get_json()
    iris, prediction = predict_single(customer, model)
    
    result = {
        'iris': iris,
    }
    return jsonify(result)

if __name__ == '__main__':
    app.run(debug=True, port=8000)